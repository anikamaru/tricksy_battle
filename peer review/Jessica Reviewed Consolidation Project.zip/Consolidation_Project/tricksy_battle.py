import random
# Card representation setup
suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades']
values = ['Ace', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen']
card_values = {name: i+1 for i, name in enumerate(values)}

# Card class definition
class Card:
    def __init__(self, suit, value):
        self.suit = suit
        self.value = value

    def __repr__(self):
        return f"{self.value} of {self.suit}"
# Deck class for managing the deck of cards
class Deck:
    def __init__(self):
        self.cards = [Card(suit, value) for suit in suits for value in values]
        random.shuffle(self.cards)

    def deal(self, num_cards):
        dealt = self.cards[:num_cards]
        self.cards = self.cards[num_cards:]
        return dealt

    def reveal_card(self):
        if self.cards:
            # Removes from end of deck (abmiguity if it is the top card or not)
            return self.cards.pop()
        return None

# Player class to manage player details and actions
class Player:
    def __init__(self, name):
        self.name = name
        self.hand = []
        self.points = 0

    def play_card(self, lead_suit=None):
        # Select playable cards matching the lead suit if possible
        playable_cards = [card for card in self.hand if card.suit == lead_suit] or self.hand
        chosen_card = random.choice(playable_cards)
        self.hand.remove(chosen_card)
        return chosen_card
 # Main game class
class TricksyBattleGame:
    def __init__(self, player1_name, player2_name):
        self.deck = Deck()
        self.player1 = Player(player1_name)
        self.player2 = Player(player2_name)
        self.rounds_played = 0

    def deal_cards(self):
        # Deal additional cards when each player has exactly 4 cards left
        self.player1.hand += self.deck.deal(4)
        self.player2.hand += self.deck.deal(4)

    def play_game(self):
        # Initial dealing of 8 cards each
        self.player1.hand = self.deck.deal(8)
        self.player2.hand = self.deck.deal(8)

        # Randomly select the starting player
        leader = self.player1 if random.choice([True, False]) else self.player2
        print(f"{leader.name} starts the game!")

        while self.rounds_played < 16:
            print(f"\nRound {self.rounds_played + 1}:")

            # Deal new cards if needed
            if len(self.player1.hand) == 4 and len(self.deck.cards) >= 8:
                self.deal_cards()

            # Leader plays a card
            card1 = leader.play_card()
            print(f"{leader.name} plays {card1}")

            # Determine the follower and their play
            follower = self.player2 if leader == self.player1 else self.player1
            card2 = follower.play_card(card1.suit)
            print(f"{follower.name} plays {card2}") 
            # Determine winner of the round
            if card2.suit == card1.suit and card_values[card2.value] > card_values[card1.value]:
                winner = follower
            else:
                winner = leader

            winner.points += 1
            print(f"{winner.name} wins this round and has {winner.points} points.")

            # Reveal a card from the deck for informational purposes
            revealed = self.deck.reveal_card()
            if revealed:
                print(f"Revealed card from deck: {revealed}")

            # Check for early game end condition
            if winner.points == 9 and (self.player1.points > 0 and self.player2.points > 0):
                print("Game ends early due to unbeatable lead.")
                break

            leader = winner
            self.rounds_played += 1
        self.determine_winner()

    def determine_winner(self):
        # Apply "shoot the moon" rule
        if self.player1.points == 0 and self.player2.points == 16:
            self.player1.points = 17
        elif self.player2.points == 0 and self.player1.points == 16:
            self.player2.points = 17

        # Display final scores
        print(f"\nGame Over! Final Score: {self.player1.name}: {self.player1.points}, {self.player2.name}: {self.player2.points}")

        # Determine the winner
        # Here the case of a tie is not handled correctly
        winner = self.player1 if self.player1.points > self.player2.points else self.player2
        print(f"{winner.name} wins the game!")

        # Save game results to a file
        with open('tricksy_battle_results.txt', 'a') as file:
            file.write(f"{self.player1.name}: {self.player1.points}, {self.player2.name}: {self.player2.points} - Winner: {winner.name}\n") 
if __name__ == '__main__':
    game = TricksyBattleGame("Player 1", "Player 2")
    game.play_game()