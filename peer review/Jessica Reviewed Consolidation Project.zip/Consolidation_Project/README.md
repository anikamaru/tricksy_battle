# Tricksy Battle Card Game

## Overview
This Python program is a simple two-player card game called "Tricksy Battle." Players take turns playing cards to win rounds by following suit and playing higher-value cards. Scores and the winner are displayed at the end of the game, and results are saved in a file.

## How to Run
1. Make sure Python is installed.
2. Save `tricksy_battle.py` in your working directory.
3. Open a terminal or command prompt and run:
python tricksy_battle.py


## How the Game Works
- Each player starts with 8 cards from a shuffled deck (standard deck without Kings).
- Players take turns playing one card each round.
- The first card played sets the "lead suit," and the second player must follow this suit if possible.
- The highest card in the lead suit wins the round and earns 1 point.
- Players draw more cards twice during the game when they each have exactly 4 cards left.
- The game ends early if one player reaches 9 points, or it continues until 16 rounds are played.
- Final scores and winner are displayed on the screen and saved in `tricksy_battle_results.txt`.